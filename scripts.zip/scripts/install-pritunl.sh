#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

ACME_DOMAIN="${PRITUNL_DOMAIN:-security.unifield.udstec.io}"

log() { echo "=== [$(date '+%Y-%m-%d %H:%M:%S')] $1 ==="; }

log "Atualizando sistema"
apt-get update -y
apt-get upgrade -y

log "Configurando repositórios"

tee /etc/apt/sources.list.d/mongodb-org.list << EOF
deb [ signed-by=/usr/share/keyrings/mongodb-server-8.0.gpg ] https://repo.mongodb.org/apt/ubuntu noble/mongodb-org/8.0 multiverse
EOF

tee /etc/apt/sources.list.d/openvpn.list << EOF
deb [ signed-by=/usr/share/keyrings/openvpn-repo.gpg ] https://build.openvpn.net/debian/openvpn/stable noble main
EOF

tee /etc/apt/sources.list.d/pritunl.list << EOF
deb [ signed-by=/usr/share/keyrings/pritunl.gpg ] https://repo.pritunl.com/stable/apt noble main
EOF

apt-get install -y gnupg curl
curl -fsSL https://www.mongodb.org/static/pgp/server-8.0.asc | gpg -o /usr/share/keyrings/mongodb-server-8.0.gpg --dearmor --yes
curl -fsSL https://swupdate.openvpn.net/repos/repo-public.gpg | gpg -o /usr/share/keyrings/openvpn-repo.gpg --dearmor --yes
curl -fsSL https://raw.githubusercontent.com/pritunl/pgp/master/pritunl_repo_pub.asc | gpg -o /usr/share/keyrings/pritunl.gpg --dearmor --yes

apt-get update -y

log "Instalando MongoDB + Pritunl + dependências"
apt-get install -y pritunl openvpn mongodb-org wireguard wireguard-tools \
  fail2ban unattended-upgrades apt-listchanges

log "Configurando unattended-upgrades"
cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

log "Configurando fail2ban"
cat > /etc/fail2ban/jail.local << 'EOF'
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 5
bantime = 1800
findtime = 600
EOF

log "Hardening SSH"
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart ssh 2>/dev/null || systemctl restart sshd

log "Habilitando IP forwarding"
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi
sysctl -p

log "Iniciando MongoDB"
mkdir -p /etc/systemd/system/mongod.service.d
cat > /etc/systemd/system/mongod.service.d/rseq.conf << 'EOF'
[Service]
Environment=GLIBC_TUNABLES=glibc.pthread.rseq=1
EOF
systemctl daemon-reload
systemctl enable mongod
systemctl start mongod

for i in $(seq 1 40); do
    if ss -ltn | grep -q ':27017'; then
        break
    fi
    log "Aguardando MongoDB ($i)"
    sleep 2
done

if ! ss -ltn | grep -q ':27017'; then
    journalctl -u mongod -n 80 --no-pager
    exit 1
fi

log "Iniciando Pritunl"
systemctl enable pritunl
systemctl start pritunl
sleep 10

log "Configurando Pritunl"
pritunl set-mongodb mongodb://localhost:27017/pritunl
pritunl set app.server_ssl true
pritunl set app.server_port 443

if [ -n "$ACME_DOMAIN" ]; then
    log "Configurando SSL Let's Encrypt para: $ACME_DOMAIN"
    pritunl set app.acme_domain "$ACME_DOMAIN"
fi

systemctl restart pritunl
sleep 15

systemctl enable fail2ban
systemctl restart fail2ban

log "Obtendo credenciais de acesso"
SETUP_KEY=$(pritunl setup-key)
DEFAULT_PASS=$(pritunl default-password 2>&1)

cat > /root/pritunl-credentials.txt << EOF
============================================================
Pritunl VPN Server - UnifiedCore
============================================================

URL:        https://${ACME_DOMAIN}
Setup Key:  $SETUP_KEY

$DEFAULT_PASS

============================================================
Pós-instalação (via painel web):

1. Acesse a URL e insira o Setup Key
2. Login com credenciais padrão acima
3. TROQUE A SENHA imediatamente
4. Crie uma Organization (ex: "UnifiedCore")
5. Crie um Server (anote a porta UDP gerada)
6. Attach a Organization ao Server
7. Adicione a porta UDP no Security Group da EC2
8. Start Server
9. Crie usuários e distribua os perfis .ovpn
============================================================

Security Group necessário:
  - 443/TCP   (HTTPS - Painel Admin)
  - 80/TCP    (HTTP - ACME challenge)
  - <PORTA>/UDP  (OpenVPN - porta gerada pelo Pritunl)

Acesso via SSM:
  aws ssm start-session --target <INSTANCE_ID>
============================================================
EOF

chmod 600 /root/pritunl-credentials.txt

log "Instalação concluída!"
echo ""
echo "  Setup Key: $SETUP_KEY"
echo "  Acesse: https://$ACME_DOMAIN"
echo "  Credenciais: /root/pritunl-credentials.txt"
echo ""
log "FIM"
