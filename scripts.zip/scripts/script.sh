# Pritunl VPN — CEISC Beta (AWS)

**Profile AWS CLI:** `ceisc_beta`  
**Domínio:** `security.ceisc.dev.br`  
**OS:** Ubuntu 26.04 LTS (Resolute Raccoon)  
**Instance Type:** t3.small | 20GB gp3 encrypted  
**Repos Pritunl/MongoDB:** codename `noble` (compatível com 26.04)

---

## 1. Login SSO

```bash
aws sso login --profile ceisc_beta
```

---

## 2. Obter AMI Ubuntu 26.04 LTS (oficial Canonical)

```bash
AMI_ID=$(aws ssm get-parameters \
  --names /aws/service/canonical/ubuntu/server/26.04/stable/current/amd64/hvm/ebs-gp3/ami-id \
  --query 'Parameters[0].Value' --output text --profile ceisc_beta)
echo "AMI: $AMI_ID"
```

---

## 3. Levantar infra existente

```bash
# VPCs
aws ec2 describe-vpcs \
  --query 'Vpcs[*].[VpcId,Tags[?Key==`Name`].Value|[0]]' \
  --output table --profile ceisc_beta

# Subnets públicas
aws ec2 describe-subnets \
  --filters "Name=map-public-ip-on-launch,Values=true" \
  --query 'Subnets[*].[SubnetId,AvailabilityZone,Tags[?Key==`Name`].Value|[0]]' \
  --output table --profile ceisc_beta

# Key Pairs
aws ec2 describe-key-pairs \
  --query 'KeyPairs[*].KeyName' --output table --profile ceisc_beta
```

---

## 4. Criar Security Group

```bash
SG_ID=$(aws ec2 create-security-group \
  --group-name pritunl-vpn-sg \
  --description "Pritunl VPN Server - CEISC" \
  --vpc-id <VPC_ID> \
  --query 'GroupId' --output text --profile ceisc_beta)

aws ec2 authorize-security-group-ingress --group-id $SG_ID \
  --ip-permissions '[
    {"IpProtocol":"tcp","FromPort":443,"ToPort":443,"IpRanges":[{"CidrIp":"0.0.0.0/0","Description":"HTTPS Painel"}]},
    {"IpProtocol":"tcp","FromPort":80,"ToPort":80,"IpRanges":[{"CidrIp":"0.0.0.0/0","Description":"HTTP ACME"}]},
    {"IpProtocol":"udp","FromPort":10000,"ToPort":20000,"IpRanges":[{"CidrIp":"0.0.0.0/0","Description":"OpenVPN UDP"}]}
  ]' --profile ceisc_beta

echo "SG: $SG_ID"
```

---

## 5. Criar script `install-pritunl.sh`

Salvar o conteúdo abaixo como `install-pritunl.sh`:

```bash
#!/bin/bash
# ============================================================
# Pritunl VPN Server - Ubuntu 26.04 LTS (Resolute Raccoon)
# CEISC Beta - security.ceisc.dev.br
# ============================================================
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

ACME_DOMAIN="${PRITUNL_DOMAIN:-security.ceisc.dev.br}"

log() { echo "=== [$(date '+%Y-%m-%d %H:%M:%S')] $1 ==="; }

# --- 1. Atualizar sistema ---
log "Atualizando sistema"
apt-get update -y
apt-get upgrade -y

# --- 2. Repositórios (noble - compatível com 26.04) ---
log "Configurando repositórios"

# MongoDB 8.0
tee /etc/apt/sources.list.d/mongodb-org.list << EOF
deb [ signed-by=/usr/share/keyrings/mongodb-server-8.0.gpg ] https://repo.mongodb.org/apt/ubuntu noble/mongodb-org/8.0 multiverse
EOF

# OpenVPN (repo oficial)
tee /etc/apt/sources.list.d/openvpn.list << EOF
deb [ signed-by=/usr/share/keyrings/openvpn-repo.gpg ] https://build.openvpn.net/debian/openvpn/stable noble main
EOF

# Pritunl
tee /etc/apt/sources.list.d/pritunl.list << EOF
deb [ signed-by=/usr/share/keyrings/pritunl.gpg ] https://repo.pritunl.com/stable/apt noble main
EOF

# Importar chaves GPG
apt-get install -y gnupg curl
curl -fsSL https://www.mongodb.org/static/pgp/server-8.0.asc | gpg -o /usr/share/keyrings/mongodb-server-8.0.gpg --dearmor --yes
curl -fsSL https://swupdate.openvpn.net/repos/repo-public.gpg | gpg -o /usr/share/keyrings/openvpn-repo.gpg --dearmor --yes
curl -fsSL https://raw.githubusercontent.com/pritunl/pgp/master/pritunl_repo_pub.asc | gpg -o /usr/share/keyrings/pritunl.gpg --dearmor --yes

apt-get update -y

# --- 3. Instalar pacotes ---
log "Instalando MongoDB + Pritunl + dependências"
apt-get install -y pritunl openvpn mongodb-org wireguard wireguard-tools \
  fail2ban unattended-upgrades apt-listchanges

# --- 4. Atualizações automáticas de segurança ---
log "Configurando unattended-upgrades"
cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

# --- 5. Fail2ban ---
log "Configurando fail2ban"
cat > /etc/fail2ban/jail.local << 'EOF'
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 5
bantime = 1800
findtime = 600
EOF

# --- 6. Hardening SSH ---
log "Hardening SSH"
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd

# --- 7. IP Forwarding ---
log "Habilitando IP forwarding"
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi
sysctl -p

# --- 8. Iniciar serviços ---
log "Iniciando MongoDB"
systemctl enable mongod
systemctl start mongod

log "Iniciando Pritunl"
systemctl enable pritunl
systemctl start pritunl
sleep 10

# --- 9. Configurar Pritunl ---
log "Configurando Pritunl"
pritunl set-mongodb mongodb://localhost:27017/pritunl
pritunl set app.server_ssl true
pritunl set app.server_port 443

if [ -n "$ACME_DOMAIN" ]; then
    log "Configurando SSL Let's Encrypt para: $ACME_DOMAIN"
    pritunl set app.acme_domain "$ACME_DOMAIN"
fi

systemctl restart pritunl
sleep 15

# --- 10. Fail2ban start ---
systemctl enable fail2ban
systemctl restart fail2ban

# --- 11. Credenciais ---
log "Obtendo credenciais de acesso"
SETUP_KEY=$(pritunl setup-key)
DEFAULT_PASS=$(pritunl default-password 2>&1)

cat > /root/pritunl-credentials.txt << EOF
============================================================
Pritunl VPN Server - CEISC Beta
============================================================

URL:        https://${ACME_DOMAIN}
Setup Key:  $SETUP_KEY

$DEFAULT_PASS

============================================================
Pós-instalação (via painel web):

1. Acesse a URL e insira o Setup Key
2. Login com credenciais padrão acima
3. TROQUE A SENHA imediatamente
4. Crie uma Organization (ex: "CEISC")
5. Crie um Server (anote a porta UDP gerada)
6. Attach a Organization ao Server
7. Adicione a porta UDP no Security Group da EC2
8. Start Server
9. Crie usuários e distribua os perfis .ovpn
============================================================

Security Group necessário:
  - 443/TCP   (HTTPS - Painel Admin)
  - 80/TCP    (HTTP - ACME challenge)
  - <PORTA>/UDP  (OpenVPN - porta gerada pelo Pritunl)

Acesso via SSM:
  aws ssm start-session --target <INSTANCE_ID> --profile ceisc_beta
============================================================
EOF

chmod 600 /root/pritunl-credentials.txt

# --- 12. Output ---
log "Instalação concluída!"
echo ""
echo "  Setup Key: $SETUP_KEY"
echo "  Acesse: https://$ACME_DOMAIN"
echo "  Credenciais: /root/pritunl-credentials.txt"
echo ""
log "FIM"
```

---

## 6. Lançar EC2

```bash
INSTANCE_ID=$(aws ec2 run-instances \
  --image-id $AMI_ID \
  --instance-type t3.small \
  --key-name <KEY> \
  --subnet-id <PUBLIC_SUBNET> \
  --security-group-ids $SG_ID \
  --iam-instance-profile Name=ssm \
  --associate-public-ip-address \
  --block-device-mappings '[{"DeviceName":"/dev/sda1","Ebs":{"VolumeSize":20,"VolumeType":"gp3","Encrypted":true}}]' \
  --user-data file://install-pritunl.sh \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=pritunl-vpn-ceisc}]' \
  --query 'Instances[0].InstanceId' --output text \
  --profile ceisc_beta)

echo "Instance: $INSTANCE_ID"
```

---

## 7. Elastic IP + DNS

```bash
# Alocar EIP
EIP_ALLOC=$(aws ec2 allocate-address --domain vpc \
  --query 'AllocationId' --output text --profile ceisc_beta)

# Associar à instância
aws ec2 associate-address \
  --instance-id $INSTANCE_ID \
  --allocation-id $EIP_ALLOC \
  --profile ceisc_beta

# Obter IP público
EIP=$(aws ec2 describe-addresses \
  --allocation-ids $EIP_ALLOC \
  --query 'Addresses[0].PublicIp' --output text --profile ceisc_beta)

echo "Elastic IP: $EIP"
echo "Criar DNS A record: security.ceisc.dev.br -> $EIP"
```

> **DNS:** Criar registro A `security.ceisc.dev.br` apontando para o Elastic IP no provedor de DNS.

---

## 8. Verificar credenciais via SSM

```bash
# Aguardar ~5 min para user-data finalizar
aws ssm start-session --target $INSTANCE_ID --profile ceisc_beta

# Dentro da instância:
cat /root/pritunl-credentials.txt
```

---

## 9. Pós-instalação (Painel Web)

1. Acessar `https://security.ceisc.dev.br`
2. Inserir **Setup Key**
3. Login com credenciais padrão
4. **Trocar senha imediatamente**
5. Criar Organization → `CEISC`
6. Criar Server (anotar porta UDP)
7. Attach Organization ao Server
8. **Atualizar Security Group** com a porta UDP exata:
   ```bash
   aws ec2 authorize-security-group-ingress --group-id $SG_ID \
     --protocol udp --port <PORTA_PRITUNL> --cidr 0.0.0.0/0 \
     --profile ceisc_beta
   ```
9. Start Server no painel
10. Criar usuários e baixar perfis `.ovpn`

---

## Notas

| Item | Detalhe |
|------|---------|
| **Repos** | MongoDB 8.0 e Pritunl usam codename `noble` (não existe `resolute` oficial ainda) |
| **Compatibilidade** | Testado e funcional — 26.04 é baseado em noble, libs são compatíveis |
| **SSL** | Let's Encrypt automático via Pritunl (precisa DNS resolvendo antes do boot) |
| **SSM** | Instance Profile `ssm` precisa existir com policy `AmazonSSMManagedInstanceCore` |
| **Firewall** | UFW desabilitado pelo Pritunl — controle feito via Security Group |
| **Referência** | Baseado no deploy mLetras, adaptado para Ubuntu 26.04 + MongoDB 8.0 |
 