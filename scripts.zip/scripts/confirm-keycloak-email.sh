#!/usr/bin/env bash
set -euo pipefail
exec python3 - "$@" <<'PY'
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE = os.environ.get("KC_BASE", "https://api.develop.orvalpay.com")
REALM = os.environ.get("KC_REALM", "ucs-platform")
CLIENT_ID = os.environ.get("KC_CLIENT_ID", "ucs-auth-admin")
CLIENT_SECRET = os.environ.get(
    "KC_CLIENT_SECRET", "uzm4jEsc7L4tZDk4vMuNd76GxZjn3tP8"
)

EMAILS = sys.argv[1:] or [
    "gustavo.santos@uds.com.br",
    "gustavo.santos+01@uds.com.br",
    "gustavo.santos+02@uds.com.br",
    "maria@email.com",
]


def request(method, url, data=None, headers=None, form=False):
    body = None
    hdrs = dict(headers or {})
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode()
            hdrs["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = json.dumps(data).encode()
            hdrs["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, method=method, headers=hdrs)
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read()
            if not raw:
                return None
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", "replace")
        raise SystemExit(f"{method} {url}\nHTTP {exc.code}\n{err}") from exc


def fetch_token(realm):
    return request(
        "POST",
        f"{BASE}/realms/{realm}/protocol/openid-connect/token",
        {
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
        form=True,
    )["access_token"]


try:
    token = fetch_token(REALM)
    token_realm = REALM
except SystemExit:
    token = fetch_token("master")
    token_realm = "master"

print(f"Token ok (realm {token_realm})")

auth = {"Authorization": f"Bearer {token}"}

for email in EMAILS:
    query = urllib.parse.urlencode({"email": email, "exact": "true"})
    users = request(
        "GET",
        f"{BASE}/admin/realms/{REALM}/users?{query}",
        headers=auth,
    ) or []
    if not users:
        print(f"NAO ENCONTRADO  {email}")
        continue
    for user in users:
        was = user.get("emailVerified")
        user["emailVerified"] = True
        request(
            "PUT",
            f"{BASE}/admin/realms/{REALM}/users/{user['id']}",
            user,
            headers=auth,
        )
        print(
            f"CONFIRMADO      {email}  username={user.get('username')}  "
            f"id={user['id']}  era_verificado={was}"
        )
PY
