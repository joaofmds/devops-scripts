#!/usr/bin/env bash
set -euo pipefail

HOST="${PGHOST:-ucs-dev-shared.cqxe4yuu8z6q.us-east-1.rds.amazonaws.com}"
PORT="${PGPORT:-5432}"
ADMIN_USER="${PGUSER:-ucs_admin}"
ADMIN_DB="${ADMIN_DB:-ucs}"
NEW_USER="murilo.fertunani"
raw="$(openssl rand -base64 24)"
NEW_PASSWORD="$(printf '%s' "$raw" | tr -dc 'A-Za-z0-9')"
NEW_PASSWORD="${NEW_PASSWORD:0:12}"
PGPASSWORD="CxXrxfR1Ukck1Pxy1O0IGa2QQ9IYsvd8"
export PGPASSWORD

if [[ ! "$NEW_USER" =~ ^[a-zA-Z0-9_.]+$ ]]; then
  echo "NEW_USER invalido"
  exit 1
fi

PASSWORD_SQL="${NEW_PASSWORD//\'/\'\'}"
USER_IDENT="\"${NEW_USER}\""

DATABASES=(
  kyc
  compliance
  payout
  audit
  i18n
  kyb
  beneficiary
  report
  support
  fees
  wallet
  treasury
  auth
)

psql_db() {
  local db="$1"
  shift
  psql "host=${HOST} port=${PORT} user=${ADMIN_USER} dbname=${db} sslmode=require" \
    -v ON_ERROR_STOP=1 \
    "$@"
}

psql_db "$ADMIN_DB" <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${NEW_USER}') THEN
    CREATE USER ${USER_IDENT} WITH LOGIN PASSWORD '${PASSWORD_SQL}';
  ELSE
    ALTER USER ${USER_IDENT} WITH PASSWORD '${PASSWORD_SQL}';
  END IF;
END
\$\$;
SQL

for db in "${DATABASES[@]}"; do
  echo "=== ${db} ==="
  psql_db "$ADMIN_DB" -c "GRANT CONNECT ON DATABASE ${db} TO ${USER_IDENT};"
  psql_db "$db" <<SQL
GRANT USAGE, CREATE ON SCHEMA public TO ${USER_IDENT};
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ${USER_IDENT};
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ${USER_IDENT};
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO ${USER_IDENT};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${USER_IDENT};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO ${USER_IDENT};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO ${USER_IDENT};
SQL
done

echo "OK: ${NEW_USER} com acesso full em public nos ${#DATABASES[@]} bancos"
echo
echo "Usuario: ${NEW_USER}"
echo "Senha:   ${NEW_PASSWORD}"
